package codigo;

import javax.swing.*;

public class Main extends JFrame {

		JLabel lblNome, lblTel, lblEmail, lblCpf;
		JTextField txtNome, txtTel, txtEmail, txtCpf;
		JButton btnEnviar;
		JTextArea txtArea;
		
		/**
	 * 
	 */
	private static final long serialVersionUID = 303333302281601911L;
		

	/* (non-Java-doc)
	 * @see java.lang.Object#Object()
	 */
	public Main() { 
		
		/*Cria a janela onde será digitado os textos e onde as informações serão exibidas */
		
		setTitle("Cadastro");
		setSize(500, 400);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);
		
		JLabel titulo = new JLabel("Cadastro");
		titulo.setBounds(170, 10, 200, 30);
		add(titulo);
		
		lblNome = new JLabel("Digite seu nome: ");
		lblNome.setBounds(30, 75, 100, 25);
		add(lblNome);
				
		txtNome = new JTextField();
		txtNome.setBounds(130, 75, 100, 25);
		add(txtNome);

		lblTel = new JLabel("Digite seu tel: ");
		lblTel.setBounds(30, 110, 100, 25);
		add(lblTel);
				
		txtTel = new JTextField();
		txtTel.setBounds(130, 110, 100, 25);
		add(txtTel);
		
		lblEmail = new JLabel("Digite seu email: ");
		lblEmail.setBounds(30, 145, 100, 25);
		add(lblEmail);
				
		txtEmail = new JTextField();
		txtEmail.setBounds(130, 145, 100, 25);
		add(txtEmail);
		
		lblCpf = new JLabel("Digite seu CPF: ");
		lblCpf.setBounds(30, 180, 100, 25);
		add(lblCpf);
				
		txtCpf = new JTextField();
		txtCpf.setBounds(130, 180, 100, 25);
		add(txtCpf);
		
		btnEnviar = new JButton("Enviar");
		btnEnviar.setBounds(200, 250, 100, 30);
		add(btnEnviar);
		
		/* Cria uma ação para quando o botão for pressionado*/
		/*Utiliza do Get e Set para pegar e definir os valores*/
		btnEnviar.addActionListener(e -> {
		    
		    String nome = txtNome.getText();
		    String telefone = txtTel.getText();
		    String email = txtEmail.getText();
		    String cpf = txtCpf.getText();
		    
		    /*Preenche a area com as informações*/
		    
		    txtArea.setText(
		        "Nome: " + nome + "\n" +
		        "Telefone: " + telefone + "\n" +
		        "Email: " + email + "\n" +
		        "CPF: " + cpf
		    );
		});

		txtArea = new JTextArea();
		txtArea.setBounds(30, 220, 150, 150);
		txtArea.setEditable(false); /*Impede que digitem na area*/
		add(txtArea);
	}
	
	public static void main(String[]args) {
		new Main().setVisible(true);		
	}
}